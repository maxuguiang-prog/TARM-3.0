import csv, json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

with (ROOT / "observed_condition_summaries.csv").open(newline="", encoding="utf-8") as f:
    observed = list(csv.DictReader(f))
with (ROOT / "expression_summary.csv").open(newline="", encoding="utf-8") as f:
    expression = list(csv.DictReader(f))
assumptions = json.loads((ROOT / "model_assumptions.json").read_text(encoding="utf-8"))

print(f"TARM {assumptions['version']} — evidence check")
print(f"Condition summaries loaded: {len(observed)}")
for row in observed:
    print(f"- {row['condition']} (Day {row['day']}): ~{row['approx_percent_cells_feeding']}% cells feeding")
print(f"Expression summary rows loaded: {len(expression)}")
print("\nInterpretation safeguards:")
for item in assumptions["key_design_constraints"]:
    print(f"- {item}")
print("\nStatus:")
for question, status in assumptions["evidence_status"].items():
    print(f"- {question}: {status}")
print("\nNo inferential statistics were run: these files contain published summaries, not replicate-level raw observations.")
