# TARM v0.3 — Evidence-aware mixoplankton response model

## Purpose
This update incorporates the published Charvet et al. (2024) *Pterosperma cristatum* study while separating observations from hypotheses. It is a research-analysis framework, not a fitted mechanistic model.

## Main research question
How do nitrogen limitation and phosphorus limitation differ in their effects on bacterial ingestion and photosynthetic performance in *Pterosperma cristatum*?

## Data included
- `observed_condition_summaries.csv`: approximate published feeding proportions and sampling design.
- `expression_summary.csv`: counts of significant transcript rows in the uploaded supplementary tables. Rows are transcript/annotation rows, not necessarily unique genes.
- `model_assumptions.json`: evidence labels, limitations, and planned future measurements.
- `analyze_tarm_v03.py`: small reproducible validation/report script.

## What changed from v0.1/v0.2
1. Adds an explicit time-confounding flag: the depleted transcriptome was sampled on Day 16 while the replete and reduced transcriptomes were sampled on Day 11.
2. Adds an explicit combined-nutrient limitation flag: f/20 reduced nitrate and phosphate together, so nitrogen-specific and phosphorus-specific effects cannot be separated.
3. Keeps feeding, cell abundance, gene expression, and photosynthetic performance as separate variables.
4. Does not convert transcript abundance into photosynthetic rate or feeding-cell percentage into ingestion rate.
5. Marks the proposed nitrogen-versus-phosphorus comparison as a future experiment rather than a result of the published data.

## Current observations
The approximate proportion of feeding cells was ~6% in replete f/2 on Day 11, ~13% in reduced f/20 on Day 11, and ~60% in depleted f/20 on Day 16. The ~60% versus ~6% comparison is about a tenfold difference in the *proportion of feeding cells*, not a tenfold increase in ingestion rate or carbon uptake.

For the significant transcript rows in the supplementary pathway tables:
- Phagotrophy-related rows: reduced 78 up / 63 down; depleted 157 up / 89 down.
- Photosynthesis-related rows: reduced 16 up / 93 down; depleted 20 up / 156 down.
- Central carbon metabolism rows: reduced 15 up / 35 down; depleted 39 up / 45 down.
These counts describe rows passing the reported significance threshold and should not be interpreted as counts of unique genes or direct measurements of metabolic activity.

## Model structure
The framework tracks:
- Nutrient condition: replete / reduced-combined / depleted-combined / future N-limited / future P-limited.
- Culture day.
- Nitrate and phosphate concentration (when measured).
- Feeding frequency or fraction of feeding cells.
- Cell abundance.
- Photosynthetic performance (not measured directly in the 2024 study).
- Gene-expression evidence (separate evidence layer).

No single trophic-allocation index is calculated yet because a comparable quantitative photosynthesis measurement is missing. A formula that combines feeding and photosynthesis would be misleading until both are measured on a compatible scale.

## Next experiment design
At minimum compare nutrient-replete, N-limited, and P-limited treatments while holding light, temperature, starting cell abundance, prey availability, and sampling schedule constant. Measure nitrate and phosphate to verify the treatments. Use biological replicates and measure feeding, cell abundance, and a direct photosynthetic-performance proxy at the same time points. Dissolved oxygen can be an indirect proxy but needs light/dark controls and is not identical to carbon fixation.

## Reproducibility
Run:
`python analyze_tarm_v03.py`

The script checks the data files and prints the core limitations. It does not perform statistical tests because the published values available here are condition summaries rather than raw replicate-level observations.
